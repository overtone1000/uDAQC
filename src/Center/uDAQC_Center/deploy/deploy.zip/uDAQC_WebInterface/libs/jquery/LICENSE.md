JQuery is released under the MIT License as described in the file header.
https://jquery.org/license/